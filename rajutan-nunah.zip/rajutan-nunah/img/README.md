# Folder Gambar — Rajutan by Nunah

Letakkan gambar-gambar produk Anda di sini.

## Nama file yang dibutuhkan:

| Nama File       | Digunakan untuk               | Ukuran Ideal   |
|-----------------|-------------------------------|----------------|
| hero1.jpg       | Hero - gambar kiri (besar)    | 600 x 400 px   |
| hero2.jpg       | Hero - gambar kanan atas      | 400 x 300 px   |
| hero3.jpg       | Hero - gambar kanan bawah     | 400 x 300 px   |
| product1.jpg    | Produk 1 — Sepatu Bayi Rose   | 400 x 300 px   |
| product2.jpg    | Produk 2 — Gantungan Kunci    | 400 x 300 px   |
| product3.jpg    | Produk 3 — Boneka Amigurumi   | 400 x 300 px   |
| product4.jpg    | Produk 4 — Gantungan Pelangi  | 400 x 300 px   |
| yarn-icon.png   | Ikon di bagian Custom Order   | 100 x 100 px   |

## Tips:
- Format: JPG atau PNG (JPG lebih ringan untuk web)
- Kompres gambar agar website lebih cepat: https://squoosh.app
- Jika gambar tidak ditemukan, website akan otomatis menampilkan placeholder

## Cara mengedit nama produk & harga:
Buka file `index.html` dan cari bagian produk. Ubah teks nama, harga, dan link WhatsApp sesuai kebutuhan.
